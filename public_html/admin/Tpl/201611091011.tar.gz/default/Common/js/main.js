$(document).ready(function() {
    load_ofc("sale_line_data_chart", sale_line_data_url, "100%", 350);
    load_ofc("sale_refund_data_chart", sale_refund_data_url, "100%", 350);
    $("#version_tip").html('<div id="version_tip">678微信生活 <br>400-8080-931</div>')
});